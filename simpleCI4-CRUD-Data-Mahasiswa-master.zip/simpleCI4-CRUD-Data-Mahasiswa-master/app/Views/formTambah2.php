<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Tambah Data Dosen</title>
</head>

<body>
    <h2>Form Tambah Data Dosen</h2>
    <p>
        <button type="submit" onclick="window.location='<?= site_url('tb_dosen/index') ?>'">
            Kembali
        </button>
    </p>

    <p>
        <?= form_open('tb_dosen/simpanData') ?>
        <table>
            <tr>
                <td>Kode :</td>
                <td>
                    <input type="text" name="kode" maxlength="10" autofocus>
                </td>
            </tr>
            <tr>
                <td>Nama Dosen :</td>
                <td>
                    <input type="text" name="nama_dosen" maxlength="50">
                </td>
            </tr>
            <tr>
                <td>Nama Mata Kuliah :</td>
                <td>
                    <input type="text" name="nama_matkul" maxlength="50">
                </td>
            </tr>
           
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="Simpan Data">
                </td>
            </tr>
        </table>
        <?= form_close(); ?>
    </p>
</body>

</html>