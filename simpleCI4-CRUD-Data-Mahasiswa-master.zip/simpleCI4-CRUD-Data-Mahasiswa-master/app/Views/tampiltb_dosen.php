<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Dosen</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
    </style>
</head>

<body>
    <h2>Data Dosen</h2>

    <p>
        <button type="submit" onclick="window.location='<?= site_url('tb_dosen/formTambah') ?>'">
            Tambah Data
        </button>
    </p>

    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama Dosen</th>
                <th>Mata Kuliah</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $nomor = 0;
            foreach ($tampilData as $row) :
                $nomor++;
            ?>

                <tr>
                    <th><?= $nomor; ?></th>
                    <td><?= $row->kode ?></td>
                    <td><?= $row->nama_dosen ?></td>
                    <td><?= $row->nama_matkul ?></td>
                    <td>
                        <button type="button" onclick="hapus('<?= $row->kode ?>')">
                            Hapus
                        </button>
                        <button type="submit" onclick="window.location='<?= site_url('tb_dosen/formEdit/' . $row->kode) ?>'">
                            Edit
                        </button>
                    </td>
                </tr>

            <?php
            endforeach;
            ?>
        </tbody>
    </table>

    <script>
        function hapus(kode) {
            pesan = confirm('Yakin hapus data dosen ?');

            if (pesan) {
                window.location.href = ("<?= site_url('tb_dosen/hapus/') ?>") + kode;
            } else return false;
        }
    </script>
</body>

</html>