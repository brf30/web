<?php

namespace App\Models;

use CodeIgniter\Model;

class Modeltb_dosen extends Model
{
    public function __construct()
    {
        $this->db = db_connect();
    }

    public function tampilData()
    {
        return $this->db->table('tb_dosen')->get();
    }

    public function simpan($data)
    {
        return $this->db->table('tb_dosen')->insert($data);
    }

    public function hapusData($kode)
    {
        return $this->db->table('tb_dosen')->delete(['kode' => $kode]);
    }

    public function ambilData($kode)
    {
        return $this->db->table('tb_dosen')->getWhere(['kode' => $kode]);
    }

    public function editData($data, $kode)
    {
        return $this->db->table('tb_dosen')->update($data, ['kode' => $kode]);
    }
}
