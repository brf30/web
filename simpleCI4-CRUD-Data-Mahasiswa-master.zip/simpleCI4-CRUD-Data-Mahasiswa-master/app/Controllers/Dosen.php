<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Modeltb_dosen;

class dosen extends Controller
{
    public function index()
    {
        $dosen = new Modeltb_dosen();
        $data = [
            'tampilData' => $dosen->tampilData()->getResult()
        ];

        echo view('tampiltb_dosen', $data);
    }

    public function formTambah()
    {
        helper('form');
        echo view('formTambah');
    }

    public function simpanData()
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_dosen' => $this->request->getPost('nama_dosen'),
            'nama_matkul' => $this->request->getPost('nama_matkul')
            
        ];

        $dosen = new Modeltb_dosen();
        $simpan = $dosen->simpan($data);

        if ($simpan) {
            return redirect()->to('/tb_dosen/index');
        }
    }

    public function hapus()
    {
        $uri = service('uri');
        $kode = $uri->getSegment('3');

        $dosen = new Modeltb_dosen();

        $dosen->hapusData($kode);
        return redirect()->to('/tb_dosen/index');
    }

    public function formEdit()
    {
        helper('form');
        $uri = service('uri');
        $kode = $uri->getSegment('3');

        $dosen = new Modeltb_dosen();

        $ambilData = $dosen->ambilData($kode);

        if (count($ambilData->getResult()) > 0) {
            $row = $ambilData->getRow();
            $data = [
                'kode' => $kode,
                'nama_dosen' => $row->nama_dosen,
                'nama_matkul' => $row->nama_matkul
               
            ];

            echo view('formEdit', $data);
        }
    }

    public function updateData()
    {
        $kode = $this->request->getPost('kode');
        $data = [
            'nama_dosen' => $this->request->getPost('nama_dosen'),
            'nama_matkul' => $this->request->getPost('nama_matkul')
          
        ];

        $dosen = new Modeltb_dosen();
        $update = $dosen->editData($data, $kode);

        if ($update) {
            return redirect()->to('/tb_dosen/index');
        }
    }
}
